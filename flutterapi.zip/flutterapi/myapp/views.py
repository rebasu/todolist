from django.shortcuts import render
from django.http import JsonResponse

#rest framework
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import serializers, status
from .serializers import TodolistSerializer

from .models import Todolist

#Get data
@api_view(['GET'])
def all_todolist(request):
    alltodolist = Todolist.objects.all() #SELECT * FROM Todolist
    serializer = TodolistSerializer(alltodolist, many = True)
    return Response(serializer.data, status = status.HTTP_200_OK)

#POST DATA
@api_view(['POST'])
def post_todolist(request):
    if request.method == 'POST':
        serializer = TodolistSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status = status.HTTP_201_CREATED)
        return Response(serializer.errors, status = status.HTTP_404_NOT_FOUND)


@api_view(['PUT'])
def update_todolist(request, TID):
    # localhost:8000/api/update-todolist/TID
    todo = Todolist.objects.get(id = TID)

    if request.method == 'PUT':
        data = {}
        serializer = TodolistSerializer(todo, data = request.data)
        if serializer.is_valid():
            serializer.save()
            data['status'] = 'updated'
            return Response(data = data, status = status.HTTP_200_OK)
        return Response(serializer.errors, status = status.HTTP_404_NOT_FOUND)

@api_view(['DELETE'])
def delete_todolist(request, TID):
    todo = Todolist.objects.get(id = TID)
    if request.method == 'DELETE':
        delete = todo.delete()
        data = {}
        if delete:
            data['status'] = 'deleted'
            statuscode = status.HTTP_200_OK
        else:
            data['status'] = 'failed'
            statuscode = status.HTTP_400_BAD_REQUEST
        return Response(data = data, status = statuscode)


# Create your views here.
data = [
    {
        "title": "BITCOIN",
        "subtitle": "A main stored of value (GOLD REPRESENTATIVE).",
        "image_url": "https://raw.githubusercontent.com/rebasu/BasicAPI/main/BTC.jpg",
        "detail": "    Bitcoin is a decentralized cryptocurrency originally described in a 2008 whitepaper by a person, or group of people, using the alias Satoshi Nakamoto. It was launched soon after, in January 2009.\n    Bitcoin is a peer-to-peer online currency, meaning that all transactions happen directly between equal, independent network participants, without the need for any intermediary to permit or facilitate them.\n    Bitcoin was created, according to Nakamoto’s own words, to allow “online payments to be sent directly from one party to another without going through a financial institution.”\n    Some concepts for a similar type of a decentralized electronic currency precede BTC, but Bitcoin holds the distinction of being the first-ever cryptocurrency to come into actual use."
    },
    {
        "title": "DOGE",
        "subtitle": "A meme coin, TO THE MOON!!!",
        "image_url": "https://raw.githubusercontent.com/rebasu/BasicAPI/main/DOGE.jpg",
        "detail": "    Dogecoin (DOGE) is based on the popular DOGE Internet meme and features a Shiba Inu on its logo. The open-source digital currency was created by Billy Markus from Portland, Oregon and Jackson Palmer from Sydney, Australia, and was forked from Litecoin in December 2013.\n    Dogecoin's creators envisaged it as a fun, light-hearted cryptocurrency that would have greater appeal beyond the core Bitcoin audience, since it was based on a dog meme. Tesla CEO Elon Musk posted several tweets on social media that Dogecoin is his favorite coin."
    },
    {
        "title": "ADA",
        "subtitle": "The leader of blockchain transaction technology.",
        "image_url": "https://raw.githubusercontent.com/rebasu/BasicAPI/main/ADA.jpg",
        "detail": "    Cardano is a proof-of-stake blockchain platform that says its goal is to allow “changemakers, innovators and visionaries” to bring about positive global change.The open-source project also aims to “redistribute power from unaccountable structures to the margins to individuals” — helping to create a society that is more secure, transparent and fair.\n    Cardano was founded back in 2017, and the ADA token is designed to ensure that owners can participate in the operation of the network. Because of this, those who hold the cryptocurrency have the right to vote on any proposed changes to the software.    \n    The team behind the layered blockchain say that there have already been some compelling use cases for its technology, which aims to allow decentralized apps and smart contracts to be developed with modularity.\n    Cardano is used by agricultural companies to track fresh produce from field to fork, while other products built on the platform allow educational credentials to be stored in a tamper-proof way, and retailers to clamp down on counterfeit goods."
    }
]

def Home(request):
    return JsonResponse(data = data, safe = False, json_dumps_params={'ensure_ascii': False})